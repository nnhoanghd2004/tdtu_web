/** @format */

function bangCuuChuong(so) {
	for (let i = 1; i <= 10; i++) {
		console.log(`${so} x ${i} = ${so * i}`);
	}
}

bangCuuChuong(9);
